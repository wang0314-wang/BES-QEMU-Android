# BES QEMU Android — 原型工程 0.1.0

目标：将公开项目 [0x504B0304/bes-qemu](https://github.com/0x504B0304/bes-qemu) 移植为纯本地 Android 应用。

## 当前包含
- Android Studio / Gradle 工程
- 运行、硬件配置、客体文件、运行日志、设置五个页面
- 本地 JSON 配置导入/重置
- 系统文件选择器
- 本地日志持久化
- Android NDK + CMake + JNI 桥接样板
- 目标 ABI：arm64-v8a
- Miuix UI 依赖已列入工程；目前页面为降低 API 变动风险，先使用 Compose Material 3 控件搭建

## 重要：当前不是可运行 QEMU 的 APK
`native_bridge.cpp` 目前只是 JNI 占位库，未链接 QEMU，也没有移植 BES SoC 设备模型、GLib/pixman 等依赖。首页的启动按钮只验证 UI 状态和日志流程，不会执行真实 guest.bin。此工程没有附带厂商固件。

后续必须完成：
1. 固定上游 QEMU 源码和 BES 补丁；
2. 将 Linux 构建流程改成 Android NDK 交叉编译；
3. 适配 GLib、pixman、线程、文件系统及 Android API；
4. 把模拟器核心封装成 JNI 可调用库或独立进程；
5. 接入合成客体启动/停止与真实日志；
6. 在 ARM64 Android 设备上实际验证。

## 构建
1. 安装 Android Studio，并确保有 JDK、Android SDK Platform 36、NDK、CMake 3.22.1。
2. 解压 ZIP，在 Android Studio 中打开 `BES_QEMU_Android` 文件夹。
3. 等待 Gradle Sync。首次构建需要联网下载开发依赖；安装后的应用本身不请求网络。
4. 选择 **Build > Build APK(s)**。
5. Debug APK 通常在 `app/build/outputs/apk/debug/app-debug.apk`。

如果 Miuix 依赖解析失败，可先移除 `app/build.gradle.kts` 中的 `miuix-ui-android` 依赖，先验证基础工程；再根据 Miuix 官方文档锁定版本和组件 API。Miuix 官方仓库：https://github.com/compose-miuix-ui/miuix

#include <jni.h>
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_besqemu_NativeBridge_nativeCoreStatus(JNIEnv *env, jobject) {
    return env->NewStringUTF("NATIVE_STUB_ONLY: QEMU/BES core is not ported yet");
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_besqemu_NativeBridge_nativeVersion(JNIEnv *env, jobject) {
    return env->NewStringUTF("BES-QEMU Android bridge 0.1 (stub)");
}

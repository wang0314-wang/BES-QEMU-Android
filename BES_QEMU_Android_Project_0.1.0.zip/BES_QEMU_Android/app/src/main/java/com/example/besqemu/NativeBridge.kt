package com.example.besqemu
object NativeBridge {
    init { System.loadLibrary("besqemu_stub") }
    external fun nativeCoreStatus(): String
    external fun nativeVersion(): String
}

package com.example.besqemu

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF8AB4F8), secondary = Color(0xFF9ADBC8),
                background = Color(0xFF101318), surface = Color(0xFF1A1F27)
            )) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BesQemuApp()
                }
            }
        }
    }
}

private enum class Page(val label: String) {
    HOME("运行"), CONFIG("配置"), GUEST("客体"), LOGS("日志"), SETTINGS("设置")
}

@Composable
private fun BesQemuApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("bes_qemu_local", 0) }
    var page by remember { mutableStateOf(Page.HOME) }
    var sessionActive by remember { mutableStateOf(false) }
    var configName by remember { mutableStateOf(prefs.getString("config_name", "BES 合成硬件配置") ?: "BES 合成硬件配置") }
    var configText by remember { mutableStateOf(prefs.getString("config_text", """{"name":"BES 合成硬件配置","machine":"bes1503","cpu":"arm","memory_mb":64}""") ?: "{}") }
    var guestUri by remember { mutableStateOf(prefs.getString("guest_uri", null)) }
    var logs by remember { mutableStateOf(prefs.getString("logs", "")!!.split("\n").filter { it.isNotBlank() }) }
    var info by remember { mutableStateOf(false) }

    fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs = (logs + "[$time] $message").takeLast(300)
        prefs.edit().putString("logs", logs.joinToString("\n")).apply()
    }

    val pickGuest = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            guestUri = uri.toString()
            prefs.edit().putString("guest_uri", guestUri).apply()
            addLog("已选择本地客体文件")
        }
    }
    val pickConfig = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("无法读取文件")
            val json = JSONObject(text)
            configText = text
            configName = json.optString("name", "自定义配置")
            prefs.edit().putString("config_name", configName).putString("config_text", configText).apply()
            addLog("已导入配置：$configName")
        } catch (e: Exception) { addLog("配置导入失败：${e.message}") }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("BES QEMU", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Android 本地模拟器前端", color = Color(0xFF9BA6B5), fontSize = 12.sp)
            }
            Surface(shape = RoundedCornerShape(50), color = Color(0xFF293342)) {
                Text("本地模式", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Page.values().forEach { item ->
                Surface(
                    modifier = Modifier.weight(1f).clickable { page = item },
                    shape = RoundedCornerShape(12.dp),
                    color = if (page == item) Color(0xFF33445C) else Color.Transparent
                ) {
                    Text(item.label, Modifier.padding(vertical = 12.dp), fontSize = 12.sp,
                        color = if (page == item) Color.White else Color(0xFF9BA6B5),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
        when (page) {
            Page.HOME -> LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    CardBlock {
                        Text(if (sessionActive) "前端状态：已启动" else "前端状态：已停止", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text("模拟器核心：尚未接入", color = Color(0xFFF1B970), fontSize = 13.sp)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = {
                            sessionActive = !sessionActive
                            if (sessionActive) {
                                addLog("收到启动请求")
                                val status = try { NativeBridge.nativeCoreStatus() } catch (e: Exception) { "原生桥接不可用：${e.message}" }
                                addLog(status)
                                addLog("当前仅为 UI 样板，不会执行真实客体指令")
                            } else addLog("已停止前端会话")
                        }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                            Text(if (sessionActive) "停止运行会话" else "启动运行会话")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("当前按钮仅用于验证界面与日志流程，不会运行真实 QEMU。", color = Color(0xFF9BA6B5), fontSize = 12.sp)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CardBlock(Modifier.weight(1f)) { Text("目标架构", color = Color(0xFF9BA6B5), fontSize = 12.sp); Text("ARM / Thumb", fontWeight = FontWeight.SemiBold) }
                        CardBlock(Modifier.weight(1f)) { Text("运行方式", color = Color(0xFF9BA6B5), fontSize = 12.sp); Text("纯本地", fontWeight = FontWeight.SemiBold) }
                    }
                }
                item { InfoCard("硬件配置", configName, "点击进入配置页") { page = Page.CONFIG } }
                item { InfoCard("客体文件", guestUri?.substringAfterLast('/') ?: "尚未选择", "选择本机文件") { page = Page.GUEST } }
                item { InfoCard("运行日志", "共 ${logs.size} 条记录", "查看本地调试信息") { page = Page.LOGS } }
                item {
                    CardBlock { Text("开发状态提示", fontWeight = FontWeight.SemiBold, color = Color(0xFFF1B970)); Spacer(Modifier.height(6.dp)); Text("下一阶段需要把上游 QEMU、BES 设备模型以及 GLib/pixman 等依赖适配 Android NDK。", fontSize = 13.sp) }
                }
            }
            Page.CONFIG -> Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("硬件配置", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("配置保存在应用本地；导入仅解析 JSON，不会下载内容。", color = Color(0xFF9BA6B5), fontSize = 13.sp)
                CardBlock {
                    Text(configName, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    Text(configText, fontSize = 12.sp)
                }
                Button(onClick = { pickConfig.launch(arrayOf("application/json", "text/json", "*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("导入 JSON 配置") }
                OutlinedButton(onClick = {
                    configName = "BES 合成硬件配置"
                    configText = """{"name":"BES 合成硬件配置","machine":"bes1503","cpu":"arm","memory_mb":64}"""
                    prefs.edit().putString("config_name", configName).putString("config_text", configText).apply()
                    addLog("已恢复默认配置")
                }, modifier = Modifier.fillMaxWidth()) { Text("恢复默认配置") }
                Text("配置目前只用于本地管理，真实设备参数解析待核心移植后接入。", color = Color(0xFFF1B970), fontSize = 12.sp)
            }
            Page.GUEST -> Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("客体文件", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("从手机文件选择器选取本地文件。应用没有网络权限，不会自动下载固件。", color = Color(0xFF9BA6B5), fontSize = 13.sp)
                CardBlock { Text("当前选择", color = Color(0xFF9BA6B5), fontSize = 12.sp); Spacer(Modifier.height(8.dp)); Text(guestUri ?: "尚未选择文件", fontSize = 13.sp) }
                Button(onClick = { pickGuest.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("选择客体文件") }
                OutlinedButton(onClick = { guestUri = null; prefs.edit().remove("guest_uri").apply(); addLog("已清除客体文件选择") }, modifier = Modifier.fillMaxWidth()) { Text("清除选择") }
                Text("选择文件不代表当前版本可以执行它；真实执行需要完成 QEMU 核心移植。", color = Color(0xFFF1B970), fontSize = 12.sp)
            }
            Page.LOGS -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("运行日志", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { logs = emptyList(); prefs.edit().putString("logs", "").apply() }) { Text("清空") }
                }
                if (logs.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("暂无日志", color = Color(0xFF9BA6B5)) }
                else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(logs.reversed()) { line -> CardBlock { Text(line, fontSize = 12.sp) } }
                }
            }
            Page.SETTINGS -> Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("设置", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                CardBlock {
                    Text("版本 0.1.0", fontWeight = FontWeight.SemiBold)
                    Text("本地数据 · 无账号 · 无网络权限", color = Color(0xFF9BA6B5), fontSize = 12.sp)
                }
                OutlinedButton(onClick = { addLog(try { NativeBridge.nativeVersion() } catch (e: Exception) { "原生桥接未加载" }); page = Page.LOGS }, modifier = Modifier.fillMaxWidth()) { Text("查看原生桥接版本") }
                OutlinedButton(onClick = { info = true }, modifier = Modifier.fillMaxWidth()) { Text("关于与移植状态") }
            }
        }
    }
    if (info) AlertDialog(
        onDismissRequest = { info = false },
        title = { Text("关于 BES QEMU") },
        text = { Text("当前交付的是 Android 前端、配置/日志功能与 JNI 桥接占位实现。真正的 QEMU/BES 设备模型移植尚未完成，因此当前不是可运行真实客体的模拟器。") },
        confirmButton = { TextButton(onClick = { info = false }) { Text("知道了") } }
    )
}

@Composable
private fun CardBlock(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier = modifier, shape = RoundedCornerShape(20.dp), color = Color(0xFF1A1F27)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), content = content)
    }
}
@Composable
private fun InfoCard(title: String, value: String, subtitle: String, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), color = Color(0xFF1A1F27)) {
        Column(Modifier.padding(17.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color(0xFF8AB4F8), fontSize = 14.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF9BA6B5), fontSize = 12.sp)
        }
    }
}
